package com.poc.mail.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.poc.mail.dto.MailRequest;
import com.poc.mail.dto.MailResponse;
import com.poc.mail.service.MailService;

@RestController
public class MailController {

	@Autowired
	private MailService mailService;
	
	@PostMapping("/send-mail")
	public MailResponse sendMail(@RequestBody MailRequest mailRequest) {
		Map<String, Object> model=new HashMap<>();
		model.put("name", mailRequest.getName());
		return mailService.sendMail(mailRequest, model);
	}
}
