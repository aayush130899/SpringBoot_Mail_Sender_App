package com.poc.mail.service;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.poc.mail.dto.MailRequest;
import com.poc.mail.dto.MailResponse;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

@Service
public class MailService {
	@Autowired
	private JavaMailSender mailSender;
	@Autowired
	private Configuration config;
	
	public MailResponse sendMail(MailRequest mailRequest,Map<String, Object> model) {
		MailResponse response=new MailResponse();
		MimeMessage message=mailSender.createMimeMessage();
		try {
			//here we set the media type
			MimeMessageHelper helper=new MimeMessageHelper(message,MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,StandardCharsets.UTF_8.name());
			//here we are adding attachment if any
			helper.addAttachment("wissen-logo.png", new ClassPathResource("wissen-logo.png"));
			
			Template template=config.getTemplate("mail-template.ftl");
			String html=FreeMarkerTemplateUtils.processTemplateIntoString(template, model);
			helper.setTo(mailRequest.getTo());
			helper.setText(html,true);
			helper.setFrom(mailRequest.getFrom());
			helper.setSubject(mailRequest.getSubject());
			mailSender.send(message);
			
			response.setMessage("Mail successfully sent to :"+mailRequest.getTo());
			response.setStatus(true);
			
		}
		catch (MessagingException | IOException | TemplateException exception) {
			response.setMessage("Failure in sending mail : "+exception.getMessage());
			response.setStatus(false);
		}
		return response;
	}
}
